import { useMemo, useState, useEffect } from 'react';
import { wordBank as vocab, bookCatalog, grammarSnippets } from './data/content';
import { BookOpen, Sparkles, GraduationCap, Gamepad2, ClipboardList, LogOut, LockKeyhole, Heart, Search, RefreshCw, CheckCircle2, WandSparkles, Menu, X } from 'lucide-react';

type Role = 'teacher' | 'student' | 'student1' | 'student0';
type Book = { title: string; levels: string[]; color: string; icon: string; focus: string };
const books: Book[] = [
  { title: 'First Friends', levels: ['1', '2'], color: 'peach', icon: '🌼', focus: 'Vocabulary · Game · Class Activity' },
  { title: 'Family and Friends', levels: ['Starter', '1', '2', '3', '4', '5', '6'], color: 'mint', icon: '🌈', focus: 'Vocabulary · Grammar Booster · Vocabulary Booster · Game · Class Activity' },
];
const starterWords = ['sunshine', 'wonderful', 'journey', 'puzzle', 'careful', 'surprise'];
const roleLabels: Record<Role, string> = { teacher: 'پنل معلم', student: 'دانش‌آموزان عمومی', student1: 'Family and Friends', student0: 'First Friends' };

function Cat({ happy = false }: { happy?: boolean }) {
  return <div className={`cat ${happy ? 'cat-happy' : ''}`} aria-label="گربهٔ لینگلُوم">
    <span className="cat-string" />
    <div className="cat-head"><i className="ear ear-left" /><i className="ear ear-right" /><span className="cat-eye eye-left" /><span className="cat-eye eye-right" /><span className="cat-nose" /><span className="cat-mouth" /><span className="cheek cheek-left" /><span className="cheek cheek-right" /><span className="whisker w1" /><span className="whisker w2" /><span className="whisker w3" /><span className="whisker w4" /></div>
    <div className="cat-paw paw-left" /><div className="cat-paw paw-right" />
  </div>;
}
function App() {
  useEffect(() => { if ('serviceWorker' in navigator && import.meta.env.PROD) navigator.serviceWorker.register('./sw.js').catch(() => {}); }, []);
  const [role, setRole] = useState<Role | null>(null);
  const [password, setPassword] = useState('');
  const [loginMessage, setLoginMessage] = useState('');
  const [book, setBook] = useState<Book | null>(null);
  const [level, setLevel] = useState('1');
  const [section, setSection] = useState('Vocabulary');
  const [search, setSearch] = useState('');
  const [missing, setMissing] = useState<{ word: string; answer: string } | null>(null);
  const [guess, setGuess] = useState('');
  const [checked, setChecked] = useState(false);
  const [topic, setTopic] = useState('');
  const [age, setAge] = useState('8–10');
  const [duration, setDuration] = useState('45');
  const [objective, setObjective] = useState('Vocabulary + speaking');
  const [plan, setPlan] = useState<string[] | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  const currentWords = useMemo(() => vocab.filter(v => `${v.word} ${v.meaning} ${v.category}`.toLowerCase().includes(search.toLowerCase())), [search]);
  const login = () => {
    const key = password.trim().toLowerCase();
    const map: Record<string, Role> = { teacher: 'teacher', student: 'student', student1: 'student1', student0: 'student0' };
    if (!map[key]) { setLoginMessage('رمز نمونه را بررسی کن و دوباره تلاش کن.'); return; }
    setRole(map[key]); setLoginMessage('خوش آمدی! ✨'); setPassword('');
  };
  const logout = () => { setRole(null); setBook(null); setPlan(null); setLoginMessage(''); };
  const makePlan = () => {
    const t = topic.trim() || 'Everyday English';
    setPlan([
      `هدف درس: زبان‌آموزان بتوانند دربارهٔ «${t}» با تمرین ${objective} از زبان انگلیسی استفاده کنند.`,
      `گروه سنی: ${age} سال | مدت: ${duration} دقیقه`,
      `۱. Warm-up (${Math.round(Number(duration) * .13)} دقیقه): با یک تصویر یا سؤال ساده، دانسته‌های قبلی را فعال کنید.`,
      `۲. Teach & Model (${Math.round(Number(duration) * .22)} دقیقه): ${t} را با مثال کوتاه، تصویر و مدل‌سازی معلم معرفی کنید.`,
      `۳. Guided Practice (${Math.round(Number(duration) * .25)} دقیقه): تمرین دونفره و تکرار هدفمند؛ خطاها را با بازخورد مهربانانه اصلاح کنید.`,
      `۴. Game / Class Activity (${Math.round(Number(duration) * .25)} دقیقه): بازی گروهی کوتاه با نوبت‌دهی و امتیاز مشارکت.`,
      `۵. Wrap-up (${Math.max(2, Math.round(Number(duration) * .15))} دقیقه): مرور سه نکتهٔ اصلی و یک سؤال خروج.`,
      `وسایل: فلش‌کارت یا تصویر، تخته، برگهٔ تمرین. ارزیابی: مشاهدهٔ مشارکت و یک پاسخ شفاهی پایانی.`,
    ]);
  };
  const newMissing = () => { const word = starterWords[Math.floor(Math.random() * starterWords.length)]; const index = Math.max(1, Math.floor(word.length / 2)); setMissing({ word: word.slice(0, index) + '_' + word.slice(index + 1), answer: word }); setGuess(''); setChecked(false); };

  if (!role) return <main className="login-page">
    <div className="login-decor decor-one" /><div className="login-decor decor-two" /><div className="login-decor decor-three" />
    <section className="login-card">
      <div className="brand-mark"><span className="brand-icon">L</span><span>lingloom</span><Sparkles size={18} /></div>
      <Cat />
      <p className="eyebrow">LEARN · PLAY · GROW</p>
      <h1>انگلیسی، با کلی رنگ و بازی!</h1>
      <p className="muted center">برای ورود، رمز پنل خودت را وارد کن.</p>
      <form onSubmit={e => { e.preventDefault(); login(); }} className="login-form">
        <label htmlFor="pass">رمز ورود</label>
        <div className="password-wrap"><LockKeyhole size={18} /><input id="pass" type="password" placeholder="رمز پنل را بنویس…" value={password} onChange={e => setPassword(e.target.value)} autoComplete="off" /><button type="submit" className="arrow-button" aria-label="ورود">↗</button></div>
        <button className="primary full" type="submit">بزن بریم! <span>✦</span></button>
      </form>
      {loginMessage && <p className="notice">{loginMessage}</p>}
      <div className="demo-hint"><span>نسخهٔ آزمایشی</span><small>teacher · student · student1 · student0</small></div>
    </section>
    <p className="footer-note">ساخته شده با <Heart size={13} fill="currentColor" /> برای کلاس‌های پر از کنجکاوی</p>
  </main>;

  const visibleBooks = role === 'student0' ? books.slice(0, 1) : role === 'student1' ? books.slice(1) : books;
  const sections = book?.title === 'First Friends'
    ? ['Vocabulary', 'Game', 'Class Activity']
    : ['Vocabulary', 'Grammar Booster', 'Vocabulary Booster', 'Game', 'Class Activity'];
  const goHome = () => { setBook(null); setPlan(null); setSection('Vocabulary'); };
  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
      <div className="brand-mark side-brand"><span className="brand-icon">L</span><span>lingloom</span></div>
      <div className="profile-mini"><div className="avatar">{role === 'teacher' ? '🧑‍🏫' : '🌟'}</div><div><strong>{roleLabels[role]}</strong><small>{role === 'teacher' ? 'آمادهٔ ساختن یک کلاس عالی؟' : 'هر روز یک کشف تازه!'}</small></div></div>
      <nav>
        <button className={!book && !plan ? 'nav-item active' : 'nav-item'} onClick={goHome}><BookOpen size={18} /> خانه و کتاب‌ها</button>
        {role === 'teacher' && <button className={plan ? 'nav-item active' : 'nav-item'} onClick={() => {setPlan(null);setBook(null);setSection('Lesson Plan');setMenuOpen(false);}}><ClipboardList size={18} /> Lesson Plan ساز</button>}
        <button className="nav-item" onClick={() => {setBook(null);setSection('Vocabulary Booster');setMenuOpen(false);}}><Sparkles size={18} /> واژه‌های تازه</button>
        <button className="nav-item" onClick={() => {setBook(null);setSection('Game');setMenuOpen(false);}}><Gamepad2 size={18} /> بازی واژگان</button>
      </nav>
      <div className="sidebar-bottom"><div className="tiny-tip"><span>💡</span><p>اشتباه کردن یعنی داری یاد می‌گیری!</p></div><button className="nav-item logout" onClick={logout}><LogOut size={18} /> خروج از حساب</button></div>
    </aside>
    {menuOpen && <button className="scrim" aria-label="بستن منو" onClick={() => setMenuOpen(false)} />}
    <main className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="منو">{menuOpen ? <X /> : <Menu />}</button><div><span className="eyebrow">HELLO THERE ✨</span><h2>{role === 'teacher' ? 'سلام معلم خلاق!' : 'سلام قهرمان کوچولو!'}</h2></div><div className="top-actions"><span className="online-dot" /> <span>فضای یادگیری تو</span><div className="avatar small">{role === 'teacher' ? '🧑‍🏫' : '🌟'}</div></div></header>
      {!book && !plan && <section className="welcome-banner"><div><span className="banner-tag"><Sparkles size={14} /> READY TO BLOOM?</span><h1>یادگیری امروزت رو<br /><em>رنگی‌تر</em> کن!</h1><p>هر کلمه یک ماجراجویی تازه است. از کجا شروع کنیم؟</p><button className="dark-button" onClick={() => {setBook(visibleBooks[0]);setLevel(visibleBooks[0].levels[0]);}}>شروع یادگیری <span>←</span></button></div><div className="banner-art"><div className="art-sun">✦</div><div className="art-book">A<span>📚</span></div><div className="art-flower">✿</div><div className="art-star">★</div><div className="art-cloud">☁</div></div></section>}
      {!book && !plan && <section className="section-block"><div className="section-heading"><div><span className="eyebrow">YOUR LEARNING SHELF</span><h3>قفسهٔ کتاب‌های تو</h3></div><span className="count-pill">{visibleBooks.length} مجموعه</span></div><div className="book-grid">{visibleBooks.map(b => <article className={`book-card ${b.color}`} key={b.title}><div className="book-cover"><span>{b.icon}</span><small>ENGLISH ADVENTURE</small><strong>{b.title}</strong><i>LET'S LEARN!</i></div><div className="book-info"><div><h4>{b.title}</h4><p>{b.levels.length} سطح یادگیری</p></div><button className="round-arrow" onClick={() => {setBook(b);setLevel(b.levels[0]);setSection('Vocabulary');}}>←</button></div><div className="level-pills">{b.levels.map(l => <button key={l} onClick={() => {setBook(b);setLevel(l);setSection('Vocabulary');}}>{l}</button>)}</div></article>)}</div></section>}
      {book && !plan && <section className="section-block">
        <button className="back-link" onClick={goHome}>← بازگشت به کتاب‌ها</button>
        <div className="section-heading"><div><span className="eyebrow">{book.title.toUpperCase()}</span><h3>{book.title} <span className="level-chip">Level {level}</span></h3></div></div>
        <div className="level-selector">{book.levels.map(l => <button className={level === l ? 'selected' : ''} key={l} onClick={() => setLevel(l)}>Level {l}</button>)}</div>
        <div className="tab-row">{sections.map(s => <button key={s} className={section === s ? 'tab selected-tab' : 'tab'} onClick={() => {setSection(s);if(s==='Game')newMissing();}}>{s}</button>)}</div>
        {section === 'Vocabulary' && <><div className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="جست‌وجوی واژه…" /></div><div className="vocab-grid">{currentWords.map((v,i) => <article className={`vocab-card vc-${i%4}`} key={v.word}><div className="vocab-art"><img src={`./assets/words/${v.word}.jpg`} alt={v.word} loading="lazy" onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} /><span>{v.emoji}</span></div><span className="word-label">WORD SPOTLIGHT</span><h4>{v.word}</h4><p className="meaning">{v.meaning}</p><p className="example">{v.example}</p><button className="listen-button" onClick={() => window.speechSynthesis?.speak(new SpeechSynthesisUtterance(v.word))}>🔊 شنیدن تلفظ</button></article>)}</div>{book.title==='First Friends' && <p className="info-note">در First Friends فقط واژگان، بازی و فعالیت کلاسی داریم؛ بخش گرامر در این کتاب فعال نیست.</p>}</>}
        {section === 'Grammar Booster' && <div className="feature-panel"><div className="feature-icon lilac"><BookOpen /></div><span className="eyebrow">GRAMMAR BOOSTER</span><h3>Grammar in tiny steps</h3><p>یک الگوی کوتاه، چند مثال، بعد نوبت تمرین توست.</p><div className="grammar-example"><strong>{grammarSnippets[Number(level === 'Starter' ? 0 : level) % grammarSnippets.length].title}</strong><p>{grammarSnippets[Number(level === 'Starter' ? 0 : level) % grammarSnippets.length].pattern}</p><small>{grammarSnippets[Number(level === 'Starter' ? 0 : level) % grammarSnippets.length].explanation}</small></div></div>}
        {section === 'Vocabulary Booster' && <div className="booster-panel"><div><span className="eyebrow">WORD OF THE DAY</span><h3>واژه‌های تازه برای ذهن کنجکاو</h3><p>واژه‌های کاربردی با مثال کوتاه؛ هر بار صفحه را باز کنی می‌توانی دستهٔ تازه‌ای تمرین کنی.</p></div><div className="vocab-grid">{vocab.slice(0,3).map(v => <article className="vocab-card" key={v.word}><div className="vocab-art"><img src={`./assets/words/${v.word}.jpg`} alt={v.word} loading="lazy" onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} /><span>{v.emoji}</span></div><h4>{v.word}</h4><p className="meaning">{v.meaning}</p><p className="example">{v.example}</p><span className="category-chip">{v.category}</span></article>)}</div></div>}
        {section === 'Game' && <div className="feature-panel game-panel"><div className="feature-icon peach-icon"><Gamepad2 /></div><span className="eyebrow">MISSING LETTER</span><h3>حرف گمشده رو پیدا کن!</h3><p>حرف جاافتاده را بنویس تا کلمه کامل شود.</p><button className="word-puzzle" onClick={() => {if(!missing)newMissing();}}>{missing?.word || 'w_n_erful'}</button><div className="guess-row"><input aria-label="حرف یا کلمهٔ پاسخ" value={guess} onChange={e => {setGuess(e.target.value);setChecked(false);}} placeholder="کلمهٔ کامل…" /><button className="primary" onClick={() => setChecked(true)}>بررسی</button><button className="icon-button" onClick={newMissing} aria-label="کلمهٔ تازه"><RefreshCw size={18}/></button></div>{checked && <p className={guess.trim().toLowerCase() === missing?.answer ? 'correct' : 'incorrect'}>{guess.trim().toLowerCase() === missing?.answer ? 'آفرین! درست بود! 🎉' : `دوباره امتحان کن؛ راهنمایی: ${missing?.word}`}</p>}<button className="text-button" onClick={newMissing}>کلمهٔ تازه <RefreshCw size={14}/></button></div>}
        {section === 'Class Activity' && <div className="feature-panel"><div className="feature-icon mint-icon"><GraduationCap /></div><span className="eyebrow">CLASS ACTIVITY</span><h3>Find someone who…</h3><p>با هم‌کلاسی‌ها صحبت کن و کسی را پیدا کن که جملهٔ گفته‌شده درباره‌اش درست باشد.</p><ul className="activity-list"><li>…likes drawing.</li><li>…can ride a bike.</li><li>…has a favourite book.</li></ul><p className="info-note">معلم می‌تواند جمله‌ها را با موضوع درس تغییر دهد.</p></div>}
      </section>}
      {role === 'teacher' && (section === 'Lesson Plan' || plan) && <section className="section-block"><div className="section-heading"><div><span className="eyebrow">TEACHER STUDIO</span><h3>Lesson Plan ساز هوشمند <WandSparkles size={22}/></h3><p className="muted">برنامهٔ درس آماده با قالب داخلی رایگان؛ بدون API و بدون هزینهٔ جداگانه.</p></div></div><div className="plan-layout"><div className="plan-form"><label>موضوع درس</label><input value={topic} onChange={e => setTopic(e.target.value)} placeholder="مثلاً: Food, daily routines, animals…" /><label>گروه سنی</label><select value={age} onChange={e => setAge(e.target.value)}><option>4–6</option><option>6–8</option><option>8–10</option><option>11–13</option><option>14–16</option></select><label>مدت کلاس</label><select value={duration} onChange={e => setDuration(e.target.value)}><option value="30">۳۰ دقیقه</option><option value="45">۴۵ دقیقه</option><option value="60">۶۰ دقیقه</option><option value="90">۹۰ دقیقه</option></select><label>تمرکز آموزشی</label><select value={objective} onChange={e => setObjective(e.target.value)}><option>Vocabulary + speaking</option><option>Grammar + writing</option><option>Listening + speaking</option><option>Review + game</option></select><button className="primary full" onClick={makePlan}>ساخت Lesson Plan <Sparkles size={17}/></button></div><div className="plan-preview">{plan ? <><div className="plan-title"><CheckCircle2 /><div><strong>برنامهٔ درس تو آماده است</strong><small>ساخته‌شده با قالب داخلی Lingloom</small></div></div><ol>{plan.map((p,i)=><li key={i}>{p}</li>)}</ol><button className="secondary" onClick={() => navigator.clipboard?.writeText(plan.join('\\n\\n'))}>کپی برنامه</button></> : <div className="empty-plan"><div className="empty-illustration">🗓️✨</div><h4>برنامهٔ کلاست اینجا می‌آید</h4><p>موضوع، سن و مدت را وارد کن و روی «ساخت Lesson Plan» بزن.</p></div>}</div></div><p className="info-note">توجه: این نسخه از قالب‌های داخلی استفاده می‌کند؛ اتصال به مدل هوش مصنوعی یا ذخیره‌سازی آنلاین هنوز اضافه نشده است.</p></section>}
      <footer className="app-footer">LINGLOOM <span>✦</span> LITTLE STEPS, BIG BLOOMS</footer>
    </main>
  </div>;
}
export default App;
