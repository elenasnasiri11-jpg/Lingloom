export type WordCard = { word: string; meaning: string; example: string; emoji: string; category: string };
export const wordBank: WordCard[] = [
 {word:'curious',meaning:'کنجکاو',example:'The curious child asked a question.',emoji:'🔍',category:'Personality'},
 {word:'whisper',meaning:'آهسته گفتن',example:'Please whisper in the library.',emoji:'🤫',category:'Actions'},
 {word:'brilliant',meaning:'درخشان؛ عالی',example:'That is a brilliant idea!',emoji:'💡',category:'Feelings & ideas'},
 {word:'explore',meaning:'کاوش کردن',example:'We explore a new place together.',emoji:'🧭',category:'Actions'},
 {word:'gentle',meaning:'ملایم؛ آرام',example:'Be gentle with the little kitten.',emoji:'🫧',category:'Personality'},
 {word:'discover',meaning:'کشف کردن',example:'Let’s discover something new.',emoji:'🪄',category:'Actions'},
 {word:'enormous',meaning:'بسیار بزرگ',example:'An enormous whale swam by.',emoji:'🐳',category:'Describing things'},
 {word:'patient',meaning:'صبور',example:'Be patient while your friend speaks.',emoji:'🌱',category:'Personality'},
 {word:'clever',meaning:'باهوش',example:'That was a clever solution.',emoji:'🧠',category:'Personality'},
 {word:'journey',meaning:'سفر',example:'Our journey starts in the morning.',emoji:'🗺️',category:'Places & travel'},
 {word:'wonderful',meaning:'فوق‌العاده',example:'We had a wonderful afternoon.',emoji:'🌞',category:'Feelings & ideas'},
 {word:'careful',meaning:'مراقب؛ بااحتیاط',example:'Be careful when you cross the road.',emoji:'🪴',category:'Personality'},
 {word:'surprise',meaning:'غافلگیری',example:'I have a surprise for you.',emoji:'🎁',category:'Feelings & ideas'},
 {word:'puzzle',meaning:'معما؛ پازل',example:'Can you solve this puzzle?',emoji:'🧩',category:'School & play'},
 {word:'sunshine',meaning:'نور آفتاب',example:'The sunshine warmed the garden.',emoji:'🌤️',category:'Nature'},
 {word:'brave',meaning:'شجاع',example:'The brave explorer tried again.',emoji:'🦁',category:'Personality'},
 {word:'gigantic',meaning:'غول‌آسا',example:'A gigantic tree stood in the park.',emoji:'🌳',category:'Describing things'},
 {word:'collect',meaning:'جمع‌آوری کردن',example:'We collect leaves in autumn.',emoji:'🍂',category:'Actions'},
 {word:'imagine',meaning:'تصور کردن',example:'Imagine a castle in the clouds.',emoji:'☁️',category:'Actions'},
 {word:'peaceful',meaning:'آرام و دلپذیر',example:'The garden is peaceful in the morning.',emoji:'🪷',category:'Describing things'}
];
export const bookCatalog = [
 { title:'First Friends', levels:['1','2'], audience:'young learners', color:'peach', sections:['Vocabulary','Game','Class Activity'] },
 { title:'Family and Friends', levels:['Starter','1','2','3','4','5','6'], audience:'young learners', color:'mint', sections:['Vocabulary','Grammar Booster','Vocabulary Booster','Game','Class Activity'] }
];
export const grammarSnippets = [
 {title:'Present simple', pattern:'I play. / She plays.', explanation:'برای عادت‌ها و کارهای همیشگی از حال ساده استفاده می‌کنیم.'},
 {title:'Can / can’t', pattern:'I can swim. / I can’t fly.', explanation:'برای توانایی‌ها از can و برای ناتوانی از can’t استفاده می‌کنیم.'},
 {title:'There is / There are', pattern:'There is a book. / There are two pens.', explanation:'برای گفتن اینکه چیزی وجود دارد، از there is یا there are استفاده می‌کنیم.'},
 {title:'Present continuous', pattern:'I am reading. / They are playing.', explanation:'برای کاری که همین الان در حال انجام است، از حال استمراری استفاده می‌کنیم.'},
 {title:'Past simple', pattern:'We visited Grandma.', explanation:'برای کارهای تمام‌شده در گذشته از گذشتهٔ ساده استفاده می‌کنیم.'}
];
