# Lingloom — نسخهٔ شروع قابل اجرا

این پروژه یک پایهٔ واقعی React + Vite برای وب است و با GitHub Actions نسخهٔ وب را build می‌کند. تولید Lesson Plan فعلاً کاملاً داخلی و رایگان است؛ کلید OpenAI لازم نیست.

## اجرای محلی
1. Node.js نسخهٔ 20 یا جدیدتر را نصب کنید.
2. در پوشهٔ پروژه اجرا کنید:
   ```bash
   npm install
   npm run dev
   ```
3. برای بررسی build:
   ```bash
   npm run build
   ```

## انتشار وب در GitHub Pages
1. محتویات ZIP را در یک repository جدید GitHub آپلود کنید.
2. از تب **Actions** اجرای workflow را بررسی کنید.
3. از **Settings → Pages**، گزینهٔ **GitHub Actions** را برای Source انتخاب کنید.
4. پس از موفقیت workflow، سایت از آدرس GitHub Pages همان repository قابل دسترسی است.

## ساخت APK
این نسخه فعلاً وب‌اپ responsive است. ساخت APK اندروید به مرحلهٔ بعدی نیاز دارد: افزودن Capacitor و workflow اندروید با تنظیمات امضای مناسب. این ZIP را APK آماده معرفی نمی‌کنیم و تا وقتی در CI ساخته و آزمایش نشده، ادعای APK آماده نداریم.

## ورود نمایشی
- `teacher` → پنل معلم
- `student` → دانش‌آموزان عمومی
- `student1` → Family and Friends
- `student0` → First Friends

این رمزها فقط برای نمونهٔ رابط کاربری هستند؛ احراز هویت امن و دیتابیس آنلاین هنوز در این نسخه پیاده‌سازی نشده‌اند. برای استفادهٔ واقعی، backend و مدیریت کاربران لازم است.
